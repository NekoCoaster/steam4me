MSTS Positioning Tool

This is a very easy to use tool for finding positions 
for lights, passengier views, cabviews, lights, 
headouts, effects, ANYTHING! in Sview.

Installation: Unzip to a temporary folder and Copy. 
Drag or Move the 1PosTool folder anywhere you can get at it easily, 
I reccomend the Trainset folder.

Use: Open up the locomotive in Sview, 
select File:Open second shape, and go to the 1PosTool Folder. 
(Note: the 1 is so that it's the first folder on the list-easier to find) 
It will have a screen to position it. 
Move it above, below, in front, behind, or besides the locomotive so you can see it, 
then position the place where the lines meet up on it to the location you want the 
of the new light, passview, headout, whatever. 
The numbers on the "Position Second Shape" screen is the position you put into 
the .wag or .eng. Note, the first number is distance right of the centerline, 
left being negative; the second number is height above the rails, below them 
being negative; and the third number is the distance forward of the centerline, 
negative being behind center (like steam loco's cabviews). All measurements, 
both in the .eng and in Sview, are in Meters, with a decmal, so just 
transfer the same number. The positioning is also by negative and positives, 
so you can just transfer that over too. Onece you get the hang of it, 
this all should get very easy. I can't see a simpiler or eiser way to do this.

Legal: This tool is origionally from Dickey Tarkington and Ron Paludan's flat people, 
but it is so highly modified that the file isn't even recognisable. 
Still, I should pay them credit. (This explains the "flatpeople201.ace") 
I don't really care what you do with it, but 
I request you don't try to make money off it. Long live Freeware!

Bradley Maurer
kbradley11@msn.com