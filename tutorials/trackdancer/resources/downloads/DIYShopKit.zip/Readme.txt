------------------------------------------------------------------
DIY SHOP KIT for MSTS
------------------------------------------------------------------

Another quality add-on for MSTS from Gryphon Media Design

COPYRIGHT (C) 2003-2004, Sean Lim (Gryphon Media Design)
All Rights Reserved

------------------------------------------------------------------

INSTALLATION:

(1) Unzip all files into a temporary location.

(2) Move the s-file and sd-file into your route's SHAPE folder.

(3) Move ACE file into your route's TEXTURE folder.

(4) Add (cut & paste) the following lines to your route's REF file:

Static (
    Class           ( "buildings" )
    Shadow          ( RECT )
    Filename        ( shop.s )
    Align           ( None )
    Description     ( Pawn_Shop )
)


(5) Add the model's to your route using the Route Editor

(6) Create a folder in your TSM Projects directory and move the
TSM DST-file and INSTRUCTIONS.rtf into that folder together with
the source BMP-files.

------------------------------------------------------------------
LIMITED LICENSE TO REDISTRIBUTE THE MODEL

You may create and upload your version of the model and offer it to
the Trainsim community as FREEWARE or distribute your version of 
the model with a FREEWARE route. (The example model may also be
included in a FREEWARE route).

Please acknowledge the originators of the original model and texture
in your distribution readme.txt.

The DIY SHOP KIT itself MAY NOT be redistributed.

------------------------------------------------------------------

AUTHORS' MESSAGE:

If you run into a problem or have a question or suggestion, please
feel free to contact me at the email addresses given below.

support@gryphonmediadesign.com

------------------------------------------------------------------

FOR DISTRIBUTION AS FREEWARE FOR PERSONAL, NON COMMERCIAL USE ONLY
TERMS AND CONDITIONS OF USE:

> This model(s) is/are not "public domain". 
> All repainted/modified versions must acknowledge the author(s)
of the original work.
> This model may not be distributed on CD without the author(s)' 
prior written agreement.
> By downloading and/or using this model, you have agreed with these 
Terms and Conditions of Use.

DISCLAIMER:

All units have been tested with MSTS running on an unmodified 
HP Pavilion XE783 System running under Windows ME.

We assume no responsibility or liablity for any MSTS or system 
hardware/software problems you may encounter after installing these 
modelss. By using these models, you accept all responsibility and liablity
for any computer problems that may arise subsequent to its installation
and use thereof.

THE AUTHORS' COPYRIGHTS TO ALL FILES ASSOCIATED WITH 
THIS MODEL ARE PROTECTED UNDER THE BERNE CONVENTION

Use of utilities or techniques to extract the texture data from the .ace
files except for Private personal use will consititute an infringement
on the Copyrights of the author(s) of the original texture.
------------------------------------------------------------------

GRYPHON MEDIA DESIGN
http://www.gryphonmediadesign.com/

