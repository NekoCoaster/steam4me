This is an edited camcfg.dat file that can replace the 
default one that came with the game.

Field of View values were changed to produce the affect 
of different camera lenses in external and internal 
views. Also the Yard View (7) was edited so that you 
can move about the route as if in the Route Editor 
(Remember: you must be in a "Yard Definition" area to activate Yard View (7)).

Installation:

- Back up original camcfg.dat file (located in "Train Simulator\GLOBAL").  A copy (named
  default_camcfg.dat) is also included in theis ZIP file;

- Copy the new camcfg.dat to the GLOBAL folder, click yes if promted to overwrite.


Creating a Yard Definition:
- Open Editors & Tools, go into Route Editor.
- Find the location you want to place a Yard Definition.
- Select the place object tool and click the spot you to center your
  Yard Definition at.
- A window pops up showing lists of objects.
- Find Yard Definition under the "Track Objects" category.
- Move the boundaries of the Yard Definition to the appropriate size (easiest
  to do from above, zoomed out).
- Save the route and enjoy railfanning!
- Remember: a Yard Definition can go any in a route so place them at 
  your convenience.

:Matt Voll: 2004  