Step-by-Step Guide to Building Routes for Microsoft Train Simulator (v3) by  Michael Vone
*****************************************************************************************

Michael has updated this package and very generously made it available as freeware.  As well as the Guide, his Object Rotator and the completed tutorial route are included.  The Object Rotator contains its own manual.

Installation
------------
Unpack the MSTS-RBG.zip file to any chosen folder.  There will be one .pdf file and two .zip files.  The .pdf file is the Guide itself and requires Acrobat Reader (or similar software) to be able to read it.  The .zip files should be unpacked when required, again to any chosen folders.

NOTE : if using Vista or Windows 7, it is recommended that the 'chosen folders' are not within either of the Program Files / Program Files (x86) folders.  Currently (Aug 2013) there are problems running MSTS under Windows 8 using nVidia or AMD graphics cards, but if/when these are solved, this will also apply to that OS.

Michael will not be providing any support for this package, but any queries or problems should be posted in one of the Community Forums, where there is sufficient expertise to enable solutions to be found.

Uploaded with permission :
"I give you permission to upload them to Uktrainsim.com.  And I have no objection to them also being uploaded to other sites that make them available for free."
(Extract from email from Michael Vone 10 August 2013).

Ged Saunders (slipperman)
August 2013

