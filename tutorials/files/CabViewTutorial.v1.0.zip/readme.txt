This Tutorial is really only a primer that should get you started,
and hopefully encourage you to experiment yourself. Following it
should enable you to create a working Cabview, but no doubt you will
be wanting to have a go at a specific locomotive cab with different controls
to the example included. Hopefully, have worked through this primer
you will have a good idea of where to look for the extra things you need.

The tutorial is in MS Word format. If you do not have MS Word,
you can download a free Word Viewer from the Internet http://www.microsoft.com.


Ian Morgan
ianm42@hotmail.com
August 2002
