HIDEWIRE
--------

V1.2  (C) 2005 wacampbell@rogers.com

Hidewire is used to remove the overhead wire from certain track sections.  Normally
MSTS does not allow mixing electric railroads and non-electric railroads in the 
same route.  It displays wire over all the track if the route is set to 'electric'
or non of the track otherwise.  Using this technique, originally developed by 'SWISSIE'
you can mix the two types of railroads.

INSTALLATION
------------


HIDEWIRE requires Microsoft dot NET Framework 1.1 (Redistributable) or higher from:

	http://msdn.microsoft.com/netframework/technologyinfo/howtoget/default.aspx


Install Hidewire by copying the following files to your route folder.

	HIDEWIRE.EXE
	RUNROUTE.BAT
	EDITROUTE.BAT




ELIMINATING OVERHEAD WIRE
-------------------------

In RE, mark tracksections without overhead right clicking and setting them to detail 
level 2 or 3 

Hidewire then converts those tracksections in the world files to 'static objects', 
preventing MSTS from displaying wire over them.  The original world files are saved 
with the extension .wOK

You must not edit the route after Hidewire has run.  To prevent this, Hidewire 
changes the extension of the route's .ref file to .noedit  
To make the route editable again, run the command EDITROUTE.  It restores the
original world files from the .wOK backups and restores your .ref file.

Two batch files are provided to automate the above:

EDITROUTE  - automatically un-does the HIDEWIRE changes if necessary and then launches RE
RUNROUTE   - automatically hides the wire if necessary and then launches MSTS


ADVANCED APPLICATION
--------------------

By default, HIDEWIRE looks for detail level 2 or 3 track sections to make non-electric. 
You can pass an optional parameter to HIDEWIRE to tell it to use an alternate detail 
level instead.  For example:

  HIDEWIRE 0

will hide the wire over all track sections with detail level 0.  Since 0 is the default 
detail level for track, this will hide all track except ones that you mark with a 
detail level other than 0 ( ie 1 ).   Use this method when most of your track is non-electric
and you want just a few sections to be electric.

Change the RUNROUTE.BAT file appropriately if you intend to use this feature.
No changes are needed to the EDITROUTE.BAT file.

Here are some examples:

HIDEWIRE    hides wire over track with detail level 2 or 3 ( the default )
HIDEWIRE 0  hides wire over track with detail level 0 only
HIDEWIRE 1  hides wire over track with detail level 1 only
HIDEWIRE 2  hides wire over track with detail level 2 only



NOTE
----

I have found that switches under the 'hidden wire' ( non electric track ) don't animate. 
The train is routed properly and the switch alignment is visible in the F8 display, but 
the actual points don't move. Maybe someone else could confirm this.

Also, HIDEWIRE will not hide the wire over DYNAMIC TRACK.   Don't use DYNAMIC TRACK on any 
sections where you don't intend to have overhead wire.


TROUBLESHOOTING
---------------

When I run RE, it says "Error reading editor object..."
- you can't edit routes that have the wire hidden, run EDITROUTE

I can't see the wire in MSTS
- route properties - make sure the route is 'electric'
- wire hieght - make sure wire hieght is within a reasonable range
- MSTS options - make sure visible wire is checked



MSTS = Microsoft Train Simulator


NOTICE
------

Hidewire is provided royalty free and without warranty of any kind.
Use at your own risk.
You may redistribute HIDEWIRE on other library sites so long as you
don't charge for it.




