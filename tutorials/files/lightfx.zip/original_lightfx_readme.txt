Project Name: MSTS Train Simulator Lights Fix
Tool Used: PSP 8 Pro
Author: Robert Fontaine
Comments:
-------------------------------
This file contains a new liteglow.ace to correct the light viewing of MSTS Train Simulator.
By making this new file, I improved the visibility of the lights.
Thus, we can reduce the radius by half reducing the risk of overlapping lights who are close each other.
A radius of about 0.18 is a normal radius for a light (about 7 inches).

IMPORTANT:
=========
The use of this file will require the modification of some light radius.
 
*****************************************************************************
* The texture is the property of Robert Fontaine.	          		    *
* The use of this texture does not remove the property right of the autor.  *
* You can use this texture but respect the property of the autor		    *
*****************************************************************************

Comments, problems and suggestions can be sent in English or French to my email address, which is:
the_genesis_man@cgocable.ca
-------------------------------

Installation
-------------------------------
-To install this file:

	1- Unzip this file in the Train Simulator Folder
Important: - I have included a copy of the original liteglow.ace in case you accidently overwrite the original 
---------	 without having made a backup before.

-To modify the radius in the .eng files:

	1- Make a bakup of the original .eng.
	2- Open the .eng with Wordpad or a text editor capable of writing back the file in unicode text format.
	3- Modify the required light radius.
	4- Save in Unicode text format.

	5 Try in Train Simulator 

Robert Fontaine
The_Genesis_Man
