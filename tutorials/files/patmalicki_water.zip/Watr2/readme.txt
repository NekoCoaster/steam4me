                       README

4-4-2002

 This texture was created by me as a freeware terrain texture.. please 
use it freely on your home computer But if you use this texture in a freeware uploaded route Please ask my permission to do so.. This texture is not permitted for use in a payware route with out my permission ...

This texture is a replacement for the default watertop.ace   Its is NOT animated  

to use....  open the envfiles, and the texture folder in the route you wish to install this water texture.. make a backup
of the default watertop.ace and put it in another folder( I make a folder called "OldAce" ) 
after you back up or move the default watertop.ace into the new folder.. just copy or cut and paste this new watertop .ace into the textures folder with in the Envfiles folder in the route..

This water texture is compatable with any other MSTS utility that you may have installed..


Pat Malicki

patm41

patm41@vvm.com