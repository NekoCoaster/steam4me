ROUTE DEVELOPER'S TOOLS PACKAGE FOR CREATION AND DISTRIBUTION OF MSTS ROUTES. PUBLIC DOMAIN.

WHAT'S IN THIS PACKAGE:
1. New and corrected shape files for some of the default objects that were left out of the original MSTS game.
2. Compiled DAT files that access special objects from all six routes.
3. A compiled REF file for static objects from all six routes.
4. EZstuff4.bat and some other batch files to simplify the process of adding objects to the route.
5. Install.bat to use as a template for an installation for distributing the route.
Any or all parts of this package can be used with or without other utililities. If you are writing your own ref file, or editing this one, you can edit the EZstuff4.bat and/or Install.bat file to copy only the necessary objects in your ref file. If you already have everything else you need, you could (for example) take only the compiled Forest.dat file from this package to get the 39 forest regions along with whatever else you put together. This package can be used as is, or modified to suit your needs.

TO USE:
1. Copy the contents of the Stuffitpack2 folder to the root of your route. 
2. Doubleclick on Ezstuff4.bat. Delete the \Stuffed folder from your route.
3. Rename the copy of Stuffit.ref in the root of your route to replace the route's ref file.
4. Add any custom objects or textures as desired.
5. Use either NAcustom.bat (North America) or EUcustom.bat (Europe) to copy all non - KUJU files to \Custom.
6. Create your route, keeping a list of terrain textures and sounds you used.
7. Edit Install.bat to make the final install size smaller.
8. Package route for distribution.




ADDING AND SORTING CUSTOM OBJECTS:
Since the introduction of TGAtool2 and 3D object makers, many people are adding downloaded objects and textures, and creating their own. Most custom objects come with a template for the ref file, so after renaming the copy of stuffit.ref in your route folder, you will need to edit it to add the lines for the downloaded object to it. Using Steve Thompson's pine trees as an example, I copy all the text from ref.txt:

Static (
	FileName ( PondPine1.s )
	Shadow ( ROUND )
	Class ( "Vegetation" )
	Align ( None )
	Description ( Ponderosa Pine1 )
	
)
Static (
	FileName ( Firtree1.s )
	Shadow ( ROUND )
	Class ( "Vegetation" )
	Align ( None )
	Description ( Firtree1 )
	
)


Then I open the route's ref file (the re-named Stuffit.ref), scroll to the bottom, and paste the lines after the last entry. Then I copy the files with .s and .sd extensions to the \shapes folder, and .ace files to \textures. Since the class is "vegetation", the new selections will show up in Vegetation in the object selection menu in the route editor. 

Carspawner.dat and Forest.dat can also be edited in wordpad to add or replace with custom vehicles and trees. Note custom signals will need the Sigcfg.dat and Sigscr.dat for that package to replace the compiled ones from this package. If you are adding this package to a route which already has custom signals on it, you should delete sigcfg.dat and sigscr.dat from \Stuffed\root\ before running EZstuff4. 

SORTING IT OUT:
There are two alternative batch files in the package, EUcustom.bat and NAcustom.bat. Which one you use depends on your computer's date format, I live in North America, and today being April 10th, 2002, my computer's files display as "4/10/02". If you are a European, yours will probably display "10/4/02" instead. So if your format is month/day/year, use NAcustom.bat, if it's day/month/year then use EUcustom.bat.
Paste one of those files in the root of your route after adding all the custom objects, and double click on it. This will create a new folder in the route named \custom, and any file modified after May of 2001 (the sim came out in June 2001, so any custom files will be dated after May 2001) will be copied to the corresponding subfolder in \custom. You can then delete \envfiles, \shapes, \sound, \terrtex, and \textures, and test it by copying Install.bat to the root of your route and doubleclicking it. This will copy all the default files from the six original routes, and then copy the custom files from the \custom folder back into place.




PACKAGING AND DISTRIBUTION:
For ease of packaging, I have included more bats from my belfry. Install.bat is a different version of EZstuff4.bat, and should be used instead of EZstuff4 for the actual installation batch file. Again, it is preferred that you do not use Install.bat as is, you should edit it in wordpad or notepad to cut out lines that you don't need. I included some remmed out lines under the call for the custom folder, to serve as an example of the syntax used for copying only the terrtex files you actually need. The best way to do that is to keep a notepad handy when texturing, and make a list of all the \terrtex files you actually use. There are 400 different default terrain textures, and it's rare for any route to actually use more than 20. If you use a lot of terrain textures from one region, you could save yourself some work by leaving in the line to copy all the terrtex files from that one region,  with individual lines to copy the few files that you use from other regions.
For example, leave in the line: 
"call xcopy ..\europe2\TerrTex\*.* .\Terrtex\*.* /s /y"
and cut out all the other lines for terrtex. Just by being conservative with the terrtex copying, you can save the end user 100 megs of space on the final installed size of your route.

Sound is another space saver, most developers don't use sounds from more than one region, there are 62 megabytes of sound files, and by copying only \template, USA1 (10mb) and USA2 (12.5mb) sounds, you'll save 40 megabytes by cutting out the \sound lines from the 4 routes that you don't use sounds from.

Envfiles are something else that you only need one set of, if you open your .trk file in wordpad, you will see that your route only uses the environment from the template folder. If you want European skies in your route, you can't get them by just copying the Europe1\Envfiles folder, you also need to change the lines in the .trk file to UKsun.env, UKrain.env, and UKsnow.env, or the extra envfiles are just taking up space. Also, don't use things like the Sky Conductor envfiles without asking permission from HITW first, that violates the EULA and is considered bad form.

EDITING THE BATCH FILE:
As is, with no alterations, Install.bat will copy all the envfiles, shapes, sounds, textures, and terrtex files from all six routes. A 36 tile route extracted with only the template objects and textures was 28.8 megabytes, and running the unedited batch file in that route
blew it up to 461 megabytes. For working on a new route this is fine, especially if you are new to the route editor and want to see all of the terrain textures and sounds that are available. But to save disk space, especially for distribution, and to customize your route
for your own tastes, it is necessary to edit the batch file. I have made this as easy as possible, even for those who have never worked with batch files before, just open a copy of Install.bat in wordpad, click, drag, cut and paste. The first three lines in each group of lines are optional, to save about 100 megs disk space delete the first 3 lines from 5 out of 6 groups. For example, if your route is based 
in England, you would delete the first 3 lines from europe2, japan1, japan2, usa1, and usa2, leaving only the lines to copy envfiles, sounds, and terrtex (terrain textures) from europe1 and template. Select, and highlight all five lines for europe1, click "edit, cut",
and paste them just above the line that says "rem custom objects folder********************************". Being the last set of texture files copied, the europe1 will overwrite all the previous, giving your route europe1 for all the common textures. By leaving the custom folder line last, any custom files with the same filename as a default file will overwrite that. If you rename your own custom terrtex file to terrain.ace, for example, the line to copy from the custom folder will overwrite terrain.ace with yours, provided you have run the custom.bat to copy it first.

Do not be afraid to try this even if you have never worked with batch files before, if you goof it up completely just delete it, paste another copy of Install.bat into the root of the route, and try again.


ZIPPING IT UP:
AFTER you have run NAcustom.bat or EUcustom.bat: Open Windows Explorer. Delete \Envfiles, \Shapes, \Sound, \Terrtex, and \Textures. Also, all the missing shape files should be in the \custom folder, so you can delete \Stuffed. 
Starting in the root of your route, click on "TOOLS, FIND, FILES OR FOLDERS NAMED", and in the box type *.bk *e.raw *n.raw. Select all, and hit the delete key.
To avoid confusing some of the more challenged end users, it's probably best to delete the NA or EU custom.bat and EZstuff4.bat files in the root of your route, leaving Install.bat, that's the only batch file needed for distribution. Leave all the rest of the root files there, of course. Zip up what's left, and delete the route entirely from the \Routes folder. (If you have a very large route you want to break into chunks, the best way to do that is to make a zip with only the \Tiles folder, make another zip with only the \World folder, then delete those two folders and zip up the rest as a third zip file.)
Now test the extraction, run the install.bat, and run trains on the route at noon on a sunny day, and midnight in the snow. If everything works, write a File_id.diz, and to make things easy for Nels start with "MSTS Route" Whatever it's named, so he can just glance at it and put it into the correct section in the file library. Also write a readme.txt file, with instructions on exactly what you did to install the route (if you're using my method it shouldn't be all that complicated!), and don't forget credits listing anyone's objects or textures that you used in the route.

REPACK.BAT:
Last minute addition here, this is a file with just the line from install.bat that takes the files from \custom and copies them back into the proper subfolders. Why? I dunno, if you don't have any custom files that have the same name as default files, you don't need to worry about what gets overwritten and when, so you may want to save the final install space by running repack after deleting \envfiles \shapes \sound \terrtex \textures, then deleting the \custom folder. I would have tried to automate that too, but WinXP doesn't have the DELTREE command anymore. Running REPACK.BAT and then deleting the \custom folder will leave you with the directory structure that includes only the files for your custom objects, and you can zip it up that way. It's just an easier way to sort out the custom objects.

Thanks to Chris Talpas for the original Combined.ref
Thanks to Jim Steven for the original ALL_OBJECTS.REF
This package is merely a continuation of their work.

Thanks to Craig Shortino for research and testing.
Thanks to Rich Garber (Ohio & West Virginia) and Bill Burnett (Seaview) for trying and  proving this package in their new routes.
Special Thanks to Dick van den Hoven for his VBscript to weed out duplicate entries.
Special thanks to Dick again, for fixing an untold number of extended shape errors, and teaching me how to do same.

EULA
There is none. The entire contents of this package are PUBLIC DOMAIN.
Feel free to re-distribute without modifications, or improve the package and distribute your own version of it.

Jim Ward (sniper297)
jwarde@ameritech.net

