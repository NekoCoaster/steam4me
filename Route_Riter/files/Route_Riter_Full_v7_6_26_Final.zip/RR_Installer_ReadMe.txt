Before you install Route_Riter, you must have a Java runtime program installed on your PC.
This may be downloaded from:-

http://www.java.com/

Just click the Free Download button.

When you run the Installer, it will default to c:\Program Files\Route_Riter, but
you may alter this to install it in any folder of your choosing. Once the installation
finishes, Martin Wright's graphics .dll files will  be automatically installed.

The installer will also install the programs Aceit.exe and TGATools2a.exe (You should
ensure that these are installed into Program files\Route_Riter and not into
Program Files\Route_Riter\Aceit or the program will not work)

Note re TsUtil: 

TsUtil is a suite of utilities for MSTS and is included with Route_Riter
with the permission of its author, Carl-Heinz Rave. TsUtil files are installed by default
into Route_Riter\TsUtil, however on some systems the utilities have not worked from this 
position and Route_Riter would not run. 

If this happens, proceed as follows:-
1. The user must download the latest Java version from www.java.com and install it.
2. They should then go to the folder c:\program files\Java\jre7
3. In that folder should be two sub-folders, 'bin' and 'lib'
4. Make a 3rd sub-folder named classes
5. Copy all of the files from the Route_Riter\TsUtil folder into Java\Jre6\classes
6. Run RR and on the TsUtil tab click the 'Show TsUtil Version' button

If all is well you should then see a report showing all of the TsUtil files and their version numbers.


Please send me any queries regarding this installer. It should work OK on both 32 and
64 bit systems, however under Vista and Windows 7, you should right-click on the file
RR7626FU.exe and select the 'Run as Administrator' option to install this file.

To reduce the size of the installer and because it is available in various
languages, the Help file is not included. It can be downloaded from the link
below. However a .pdf file outlining the use of the new Consist and Activity Editors
is included.

As Route_Riter can make changes to files in the Program Files folder (where MSTS is on
default systems), it must be run as administrator. To do this, right click the file
Route_Riter\Route_Riter.exe and select Properties/Compatability and tick the bottom box
'Run this program as administrator' then it will always run correctly.

Mike Simpson - 18th Feb 2013
email: rwtools@live.com.au
web: http://www.rstools.info


